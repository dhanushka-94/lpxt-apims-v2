<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">API Data Viewer</h5>
                    <div>
                        <a href="<?php echo e(route('api.docs')); ?>" class="btn btn-sm btn-secondary">View API Documentation</a>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Search and Filter Form -->
                    <form action="<?php echo e(route('api.data-view')); ?>" method="GET" class="mb-4">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="query" placeholder="Search by name or code" value="<?php echo e($query); ?>">
                                    <button class="btn btn-primary" type="submit">Search</button>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <select name="category_id" class="form-select" onchange="this.form.submit()">
                                    <option value="">All Categories</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php echo e($categoryId == $category->id ? 'selected' : ''); ?>>
                                            <?php echo e($category->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select name="per_page" class="form-select" onchange="this.form.submit()">
                                    <option value="15" <?php echo e(request('per_page') == 15 ? 'selected' : ''); ?>>15 per page</option>
                                    <option value="30" <?php echo e(request('per_page') == 30 ? 'selected' : ''); ?>>30 per page</option>
                                    <option value="50" <?php echo e(request('per_page') == 50 ? 'selected' : ''); ?>>50 per page</option>
                                    <option value="100" <?php echo e(request('per_page') == 100 ? 'selected' : ''); ?>>100 per page</option>
                                </select>
                            </div>
                        </div>
                    </form>

                    <!-- Products Table -->
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Images</th>
                                    <th>Code</th>
                                    <th>Name</th>
                                    <th>Product Specifications</th>
                                    <th>Category</th>
                                    <th>Subcategory</th>
                                    <th>Brand</th>
                                    <th>Price Info</th>
                                    <th>Promotion</th>
                                    <th>Qty</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td>
                                            <div class="d-flex flex-wrap gap-1">
                                                <?php if($product->photos->count() > 0): ?>
                                                    <?php $__currentLoopData = $product->photos->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="position-relative">
                                                            <img src="<?php echo e('https://mskcomputers.lk/assets/uploads/' . $photo->photo); ?>" 
                                                                alt="<?php echo e($product->name); ?>" class="img-thumbnail"
                                                                style="width: 50px; height: 50px; object-fit: cover;">
                                                            <?php if($index === 0): ?>
                                                                <span class="position-absolute top-0 start-0 badge bg-primary" style="font-size: 8px;">Main</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($product->photos->count() > 3): ?>
                                                        <button type="button" class="btn btn-sm btn-outline-primary" 
                                                                data-bs-toggle="modal" data-bs-target="#galleryModal-<?php echo e($product->id); ?>">
                                                            +<?php echo e($product->photos->count() - 3); ?> more
                                                        </button>
                                                    <?php endif; ?>
                                                <?php elseif($product->image): ?>
                                                    <img src="<?php echo e('https://mskcomputers.lk/assets/uploads/' . $product->image); ?>" 
                                                        alt="<?php echo e($product->name); ?>" class="img-thumbnail"
                                                        style="width: 50px; height: 50px; object-fit: cover;">
                                                <?php else: ?>
                                                    <span class="text-muted">No images</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td><?php echo e($product->code); ?></td>
                                        <td>
                                            <div><?php echo e($product->name); ?></div>
                                            <?php if($product->second_name): ?>
                                                <small class="text-muted"><?php echo e($product->second_name); ?></small>
                                            <?php endif; ?>
                                            <small class="d-block text-muted">Slug: <?php echo e($product->slug); ?></small>
                                        </td>
                                        <td>
                                            <div style="max-width: 350px; max-height: 120px; overflow: auto; border: 1px solid #eee; padding: 8px; border-radius: 4px; background-color: #f9f9f9;">
                                                <?php if($product->details): ?>
                                                    <div class="product-details">
                                                        <?php echo $product->details; ?>

                                                    </div>
                                                    <button type="button" class="btn btn-sm btn-primary mt-2" 
                                                            data-bs-toggle="modal" data-bs-target="#detailsModal-<?php echo e($product->id); ?>">
                                                        <i class="bi bi-search"></i> View Full Details
                                                    </button>
                                                <?php else: ?>
                                                    <span class="text-muted">No product specifications available</span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php echo e($product->category->name ?? 'N/A'); ?>

                                        </td>
                                        <td>
                                            <?php if($product->subcategory_id): ?>
                                                <?php
                                                    $subcategory = App\Models\Category::find($product->subcategory_id);
                                                ?>
                                                <?php echo e($subcategory ? $subcategory->name : 'ID: '.$product->subcategory_id); ?>

                                            <?php else: ?>
                                                <span class="text-muted">None</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(is_object($product->brand)): ?>
                                                <?php echo e($product->brand->name); ?>

                                            <?php else: ?>
                                                Brand ID: <?php echo e($product->brand); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div><strong>Price:</strong> <?php echo e(number_format($product->price, 2)); ?></div>
                                            <div class="<?php echo e($product->promotion_price ? 'text-success fw-bold' : 'text-muted'); ?>">
                                                <strong>Promo Price:</strong> 
                                                <?php if($product->promotion_price): ?>
                                                    <?php echo e(number_format($product->promotion_price, 2)); ?>

                                                <?php else: ?>
                                                    N/A
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if(isset($product->promotion) && $product->promotion): ?>
                                                <div><strong>Promotion:</strong> Yes</div>
                                                <?php if($product->start_date): ?>
                                                    <small class="d-block">From: <?php echo e($product->start_date); ?></small>
                                                <?php endif; ?>
                                                <?php if($product->end_date): ?>
                                                    <small class="d-block">To: <?php echo e($product->end_date); ?></small>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-muted">No promotion</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($product->quantity); ?></td>
                                        <td>
                                            <?php if($product->status): ?>
                                                <span class="badge bg-<?php echo e($product->status->status ? 'success' : 'secondary'); ?>">
                                                    <?php echo e($product->status->status_name); ?>

                                                </span>
                                                <?php if($product->date_created): ?>
                                                    <small class="d-block text-muted">Created: <?php echo e($product->date_created); ?></small>
                                                <?php endif; ?>
                                                <?php if($product->status_date): ?>
                                                    <small class="d-block text-muted">Updated: <?php echo e($product->status_date); ?></small>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Unknown</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column gap-1">
                                                <button type="button" class="btn btn-sm btn-primary" 
                                                       data-bs-toggle="modal" data-bs-target="#jsonModal-<?php echo e($product->id); ?>">
                                                    View JSON
                                                </button>
                                                <a href="#" 
                                                  onclick="navigator.clipboard.writeText('/api/products/<?php echo e($product->id); ?>'); alert('API URL copied!'); return false;" 
                                                  class="btn btn-sm btn-outline-secondary">
                                                    Copy API URL
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="13" class="text-center">No products found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="d-flex justify-content-center mt-4">
                        <?php echo e($products->appends(request()->query())->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Gallery Modals -->
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($product->photos->count() > 0 || !empty($product->image)): ?>
        <div class="modal fade" id="galleryModal-<?php echo e($product->id); ?>" tabindex="-1" aria-labelledby="galleryModalLabel-<?php echo e($product->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="galleryModalLabel-<?php echo e($product->id); ?>"><?php echo e($product->name); ?> - Image Gallery</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <?php if($product->photos->count() > 0): ?>
                                <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 col-6">
                                        <div class="position-relative">
                                            <img src="<?php echo e('https://mskcomputers.lk/assets/uploads/' . $photo->photo); ?>" 
                                                alt="<?php echo e($product->name); ?> Photo <?php echo e($index + 1); ?>" 
                                                class="img-fluid rounded">
                                            <?php if($index === 0): ?>
                                                <span class="position-absolute top-0 start-0 badge bg-primary">Main Image</span>
                                            <?php endif; ?>
                                            <div class="mt-1 small text-muted">
                                                ID: <?php echo e($photo->id); ?> | Filename: <?php echo e($photo->photo); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php elseif($product->image): ?>
                                <div class="col-md-6 mx-auto">
                                    <img src="<?php echo e('https://mskcomputers.lk/assets/uploads/' . $product->image); ?>" 
                                        alt="<?php echo e($product->name); ?>" 
                                        class="img-fluid rounded">
                                    <div class="mt-1 small text-muted">
                                        Filename: <?php echo e($product->image); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Details Modal -->
    <div class="modal fade" id="detailsModal-<?php echo e($product->id); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="bi bi-info-circle me-2"></i><?php echo e($product->name); ?> - Detailed Specifications</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <?php if($product->image): ?>
                                <img src="<?php echo e('https://mskcomputers.lk/assets/uploads/' . $product->image); ?>" 
                                    alt="<?php echo e($product->name); ?>" 
                                    class="img-fluid rounded border">
                            <?php elseif($product->photos && $product->photos->count() > 0): ?>
                                <img src="<?php echo e('https://mskcomputers.lk/assets/uploads/' . $product->photos->first()->photo); ?>" 
                                    alt="<?php echo e($product->name); ?>" 
                                    class="img-fluid rounded border">
                            <?php endif; ?>

                            <div class="mt-3">
                                <h6 class="border-bottom pb-2">Product Information</h6>
                                <p><strong>Code:</strong> <?php echo e($product->code); ?></p>
                                <p><strong>Category:</strong> <?php echo e($product->category->name ?? 'N/A'); ?></p>
                                <p><strong>Brand:</strong> <?php echo e(is_object($product->brand) ? $product->brand->name : 'Brand ID: '.$product->brand); ?></p>
                                <p><strong>In Stock:</strong> <?php echo e($product->quantity); ?> units</p>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header bg-light">
                                    <h5 class="card-title mb-0">Product Specifications</h5>
                                </div>
                                <div class="card-body product-details-full">
                                    <?php if($product->details): ?>
                                        <?php echo $product->details; ?>

                                    <?php else: ?>
                                        <span class="text-muted">No product specifications available</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="mt-3">
                                <h6 class="border-bottom pb-2">Pricing</h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="card text-center h-100">
                                            <div class="card-body">
                                                <h6 class="card-title">Regular Price</h6>
                                                <p class="card-text fw-bold fs-5"><?php echo e(number_format($product->price, 2)); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($product->promotion_price): ?>
                                    <div class="col-sm-6">
                                        <div class="card text-center bg-success text-white h-100">
                                            <div class="card-body">
                                                <h6 class="card-title">Promotion Price</h6>
                                                <p class="card-text fw-bold fs-5"><?php echo e(number_format($product->promotion_price, 2)); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="/api/products/<?php echo e($product->id); ?>" target="_blank" class="btn btn-outline-primary">
                        <i class="bi bi-code-slash me-1"></i>View API Response
                    </a>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- JSON Modal -->
    <div class="modal fade" id="jsonModal-<?php echo e($product->id); ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title"><i class="bi bi-braces-asterisk me-2"></i><?php echo e($product->name); ?> - API Response</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body bg-dark p-0">
                    <pre class="json-display m-0"><code>
{
    "success": true,
    "data": {
        "id": <?php echo e($product->id); ?>,
        "code": "<?php echo e($product->code); ?>",
        "name": "<?php echo e($product->name); ?>",
        "second_name": "<?php echo e($product->second_name ?? ''); ?>",
        "slug": "<?php echo e($product->slug ?? ''); ?>",
        "details": "<?php echo isset($product->details) ? str_replace(['"', "\r", "\n"], ['\"', '', ''], $product->details) : 'null'; ?>",
        "price": <?php echo e($product->price ?? 0); ?>,
        "promotion_price": <?php echo e($product->promotion_price ?? 'null'); ?>,
        "promotion": <?php echo e(isset($product->promotion) && $product->promotion ? 'true' : 'false'); ?>,
        "category_id": <?php echo e($product->category_id ?? 'null'); ?>,
        "subcategory_id": <?php echo e($product->subcategory_id ?? 'null'); ?>,
        "subcategory": <?php if($product->subcategory_id && $product->subcategory): ?>
            {
                "id": <?php echo e($product->subcategory->id); ?>,
                "name": "<?php echo e($product->subcategory->name); ?>"
            }
        <?php else: ?>
            null
        <?php endif; ?>,
        "quantity": <?php echo e($product->quantity ?? 0); ?>,
        "image": "<?php echo e($product->image ? 'https://mskcomputers.lk/assets/uploads/'.$product->image : null); ?>",
        "product_status": <?php echo e($product->product_status ?? 0); ?>,
        "date_created": "<?php echo e($product->date_created ?? ''); ?>",
        "status_date": "<?php echo e($product->status_date ?? ''); ?>",
        "hide": <?php echo e(isset($product->hide) && $product->hide ? 'true' : 'false'); ?>,
        "status_info": {
            "id": <?php echo e($product->product_status ?? 0); ?>,
            "name": "<?php echo e($product->status ? $product->status->status_name : 'Unknown'); ?>",
            "value": <?php echo e($product->status ? $product->status->status : 0); ?>

        },
        "category": {
            "id": <?php echo e($product->category->id ?? 'null'); ?>,
            "name": "<?php echo e($product->category->name ?? 'N/A'); ?>"
        },
        "brand": {
            "id": <?php echo e(is_object($product->brand) ? $product->brand->id : $product->brand); ?>,
            "name": "<?php echo e(is_object($product->brand) ? $product->brand->name : 'Unknown'); ?>"
        },
        "photos": [
            <?php if($product->photos->count() > 0): ?>
                <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        "id": <?php echo e($photo->id); ?>,
                        "product_id": <?php echo e($photo->product_id); ?>,
                        "photo": "https://mskcomputers.lk/assets/uploads/<?php echo e($photo->photo); ?>"
                    }<?php echo e(!$loop->last ? ',' : ''); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif($product->image): ?>
                {
                    "id": 0,
                    "product_id": <?php echo e($product->id); ?>,
                    "photo": "https://mskcomputers.lk/assets/uploads/<?php echo e($product->image); ?>"
                }
            <?php endif; ?>
        ],
        "attributes": [
            <?php if($product->attributes && $product->attributes->count() > 0): ?>
                <?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        "id": <?php echo e($attribute->id); ?>,
                        "name": <?php
                            $attributeNames = [
                                26 => 'Processor',
                                33 => 'RAM',
                                30 => 'Storage'
                            ];
                            echo '"' . ($attributeNames[$attribute->attribute_id] ?? 'Unknown Attribute') . '"';
                        ?>,
                        "value": <?php echo e($attribute->value ? '"' . $attribute->value . '"' : 'null'); ?>,
                        "attribute_id": <?php echo e($attribute->attribute_id ?? 0); ?>

                    }<?php echo e(!$loop->last ? ',' : ''); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        ]
    }
}
                    </code></pre>
                </div>
                <div class="modal-footer justify-content-between bg-dark">
                    <a href="http://127.0.0.1:8000/api/products/<?php echo e($product->id); ?>" target="_blank" class="btn btn-sm btn-outline-light">
                        <i class="bi bi-box-arrow-up-right me-1"></i>Open Direct API Link
                    </a>
                    <button type="button" class="btn btn-sm btn-outline-light copy-json" 
                            data-product-id="<?php echo e($product->id); ?>">
                        <i class="bi bi-clipboard me-1"></i>Copy JSON
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Additional Styles -->
<style>
    pre {
        background-color: #f8f9fa;
        padding: 15px;
        border-radius: 5px;
        max-height: 400px;
        overflow-y: auto;
    }
    
    .json-display {
        background-color: #1e1e1e;
        color: #d4d4d4;
        padding: 15px;
        border-radius: 0;
        max-height: 500px;
        overflow-y: auto;
        font-size: 14px;
        line-height: 1.5;
    }
    
    .json-display .text-warning {
        color: #ce9178 !important;
    }
    
    .json-display code {
        font-family: 'Cascadia Code', 'Fira Code', Consolas, 'Courier New', monospace;
        font-size: 14px;
    }
    
    .table th, .table td {
        vertical-align: middle;
    }
    
    .img-thumbnail {
        border: 1px solid #dee2e6;
        padding: 2px;
    }
    
    .product-details {
        font-size: 13px;
        line-height: 1.4;
    }
    
    .product-details-full {
        line-height: 1.6;
    }
    
    .product-details table,
    .product-details-full table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 1rem;
    }
    
    .product-details table td, 
    .product-details table th,
    .product-details-full table td,
    .product-details-full table th {
        border: 1px solid #dee2e6;
        padding: 0.5rem;
    }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const copyButtons = document.querySelectorAll('.copy-json');
        copyButtons.forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-product-id');
                const jsonContent = document.querySelector(`#jsonModal-${productId} pre code`).textContent;
                
                navigator.clipboard.writeText(jsonContent)
                    .then(() => {
                        this.textContent = 'Copied!';
                        setTimeout(() => {
                            this.textContent = 'Copy JSON';
                        }, 2000);
                    })
                    .catch(err => {
                        console.error('Failed to copy: ', err);
                    });
            });
        });
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dhanushka\Desktop\msk_api_2025\resources\views\api\data-view.blade.php ENDPATH**/ ?>